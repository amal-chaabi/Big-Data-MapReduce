package NumbersPackagDemo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;

import javax.lang.model.SourceVersion;

import org.apache.hadoop.util.Tool;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.Mapper.Context;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.GenericOptionsParser;
import org.apache.hadoop.util.ToolRunner;


public  class NumberCount extends Configured implements Tool  {
public int run (String [] args) throws Exception
{


Configuration c=new Configuration() ;
String[] files=new GenericOptionsParser(c,args).getRemainingArgs();
Path input=new Path(files[0]);
Path output=new Path(files[1]);
Job j=Job.getInstance(c,"totalNumbers");
j.setJarByClass(NumberCount.class);
j.setMapperClass(MapCount.class);
j.setReducerClass(ReduceCount.class);
j.setOutputKeyClass(Text.class);
j.setOutputValueClass(IntWritable.class);
FileInputFormat.addInputPath(j, input);
FileOutputFormat.setOutputPath(j, output);

 j.waitForCompletion(true);

Configuration c2=new Configuration();

Path output2=new Path(files[2]);
Job j2=Job.getInstance(c2,"somme");
j2.setJarByClass(NumberCount.class);
j2.setMapperClass(MapForNumbers.class);
j2.setReducerClass(ReduceForNumbers.class);
j2.setOutputKeyClass(Text.class);
j2.setOutputValueClass(IntWritable.class);
FileInputFormat.addInputPath(j2, input);
FileOutputFormat.setOutputPath(j2, output2);
return j2.waitForCompletion(true) ? 0 : 1;

}

public static void main(String[] args) throws Exception {
	int res = ToolRunner.run(new Configuration(), new NumberCount(),
			args);
	System.exit(res);
}


public static class MapCount extends Mapper<LongWritable, Text, Text , IntWritable>{
public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
String line = value.toString();
String[] words=line.split(",");
for(String word: words )
{
	int number = Integer.parseInt(word); 
	  
    if (number % 2 == 1)  
    { 
        // For Odd Numbers 
    	Text outputKey = new Text("0");
    	IntWritable outputValue = new IntWritable(1);
    	con.write(outputKey, outputValue);
    } 

    else 
    { 
        // For Even Numbers 
    	Text outputKey = new Text("1");
    	IntWritable outputValue = new IntWritable(1); 
    	con.write(outputKey, outputValue);
    } 
}
}
}

public static class MapForNumbers extends Mapper<LongWritable, Text, Text , IntWritable>{
public void map(LongWritable key, Text value, Context con) throws IOException, InterruptedException
{
String line = value.toString();
String[] words=line.split(",");
for(String word: words )
{
	int number = Integer.parseInt(word); 
	  
    if (number % 2 == 0)  
    { 
        // For Odd Numbers 
    	Text outputKey = new Text("0");
    	IntWritable outputValue = new IntWritable(number);
    	con.write(outputKey, outputValue);
    } 

    else 
    { 
        // For Even Numbers 
    	Text outputKey = new Text("1");
    	IntWritable outputValue = new IntWritable(number); 
    	con.write(outputKey, outputValue);
    } ;
}
}
}

public static class ReduceCount extends Reducer<Text, IntWritable, Text, IntWritable>
{	
	
public void reduce(Text key, Iterable<IntWritable> values, Context con) throws IOException, InterruptedException
{
int count = 0;
for(IntWritable value : values)
{
    if (key.equals("0"))  
    { 
            count++; 
    } 

    else 
    {  
            count++; 
        
    }
}

con.write( key, new IntWritable(count));
}
}






public static class ReduceForNumbers extends Reducer<Text, IntWritable, Text, IntWritable>
{	
	
public void reduce(Text key, Iterable<IntWritable> values, Context con) throws IOException, InterruptedException
{
int sum = 0;

for(IntWritable value : values)
{
	 if (key.equals("0"))  
	    { 
		 sum += Integer.parseInt(value.toString());
	    } 

	    else 
	    {  
	    	sum += Integer.parseInt(value.toString());   
	        
	    }
}
con.write( key, new IntWritable(sum));
}
}

}






